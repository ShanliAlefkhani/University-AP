public class Student extends Person{
    static int counter = 0;
    static Student[] list = new Student[100];

    Lesson[] lessonList;
    int lessonCounter = 0;
    Book borrowedBook;
    Food reservedFood;
    long money;

    public Student(String username, String password) {
        super(username, password);
    }
    boolean reserveFood(Food food) {
        if (reservedFood == null) {
            if (food.reserve()) {
                if (money >= food.price) {
                    reservedFood = food;
                    money -= food.price;
                    System.out.println("Food reserved successfully!");
                    return true;
                }
                System.out.println("Your money isn't enough!");
                return false;
            }
            System.out.println("this food is finished!");
            return false;
        }
        System.out.println("You have already reserved a food!");
        return false;
    }
    void removeFood() {
        if (reservedFood != null) {
            reservedFood.remove();
            money += reservedFood.price * 90 / 100;
            reservedFood = null;
        }
        else {
            System.out.println("You didn't reserve any food!");
        }
    }
    boolean borrowBook(Book book) {
        if (borrowedBook == null) {
            if (book.borrow(this)) {
                System.out.println("Book borrowed successfully!");
                return true;
            }
            System.out.println("This book is already borrowed!");
            return false;
        }
        System.out.println("You have already borrowed a book!");
        return false;
    }
    void returnBook() {
        if (borrowedBook != null) {
            borrowedBook.retUrn();
            borrowedBook = null;
            System.out.println("Book returned successfully!");
        }
        else {
            System.out.println("You didn't borrow any book!");
        }
    }
    boolean addLesson(Lesson lesson) {
        if (lesson.addStudent(this)) {
            lessonList[lessonCounter++] = lesson;
            return true;
        }
        System.out.println("class dige ja nadare ://");
        return false;
    }
    void addMoney(long money) {
        this.money += money;
    }
    void viewLessonList() {
        if (lessonCounter == 0) {
            System.out.println("You have no lessons!");
            return;
        }
        for (int i = 0; i < lessonCounter; i++) {
            System.out.println(i + ": " + lessonList[i].name + " ");
        }
        System.out.println();
    }
}
