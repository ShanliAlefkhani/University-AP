public class Food {
    static int counter = 0;
    static Food[] list = new Food[100];

    String name;
    long price;
    int number;

    public Food(String name, long price, int number) {
        this.name = name;
        this.price = price;
        this.number = number;
    }
    boolean reserve() {
        if (this.number > 0) {
            this.number--;
            return true;
        }
        return false;
    }
    void remove() {
        this.number++;
    }
}
