public class Professor extends Person{
    static int counter = 0;
    static Professor[] list = new Professor[100];

    int classCounter = 0;
    Lesson[] classList;

    public Professor(String username, String password) {
        super(username, password);
    }
    void setClass(String name, int classCapacity) {
        Lesson lesson = new Lesson(name, this, classCapacity);
        classList[classCounter++] = lesson;
        Lesson.list[Lesson.counter++] = lesson;
    }
    void viewClassList() {
        if (classCounter == 0) {
            System.out.println("You have no class!");
            return;
        }
        for (int i = 0; i < classCounter; i++) {
            System.out.print(i + ": " + classList[i].name + " ");
        }
        System.out.println();
    }
}
