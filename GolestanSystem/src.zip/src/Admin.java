public class Admin extends Person{
    public Admin(String username, String password) {
        super(username, password);
    }
    void addBook(String name) {
        Book book = new Book(name);
        boolean b = true;
        for (int i = 0; i < Book.counter; i++) {
            if (Book.list[i].name.equals(name)) {
                System.out.println("This book already exists!");
                b = false;
                break;
            }
        }
        if (b) {
            Book.list[Book.counter++] = book;
            System.out.println("Book added successfully!");
        }
    }
    void addFood(String name, long price, int number) {
        Food food = new Food(name, price, number);
        boolean b = true;
        for (int i = 0; i < Food.counter; i++) {
            if (Food.list[i].name.equals(name)) {
                System.out.println("This food already exists!");
                b = false;
                break;
            }
        }
        if (b) {
            Food.list[Food.counter++] = food;
            System.out.println("Food added successfully!");
        }
    }
    void showProfessorInfo(Professor professor) {
        System.out.println(professor.username + " " + professor.password);
    }
    void showStudentInfo(Student student) {
        System.out.println(student.username + " " + student.password);
    }
    static void viewBooks() {
        if (Book.counter == 0) {
            System.out.println("There is no book!");
            return;
        }
        for (int i = 0; i < Book.counter; i++) {
            System.out.println(i + ": " + Book.list[i].name + " ");
        }
        System.out.println();
    }
    static void viewFoods() {
        if (Food.counter == 0) {
            System.out.println("There is no food!");
            return;
        }
        for (int i = 0; i < Food.counter; i++) {
            System.out.println(i + ": " + Food.list[i].name + " ");
        }
        System.out.println();
    }
    static void viewLessons() {
        if (Lesson.counter == 0) {
            System.out.println("There is no lesson!");
            return;
        }
        for (int i = 0; i < Lesson.counter; i++) {
            System.out.println(i + ": " + Lesson.list[i].name + " ");
        }
        System.out.println();
    }
    static void viewProfessors() {
        if (Professor.counter == 0) {
            System.out.println("There is no professor!");
            return;
        }
        for (int i = 0; i < Professor.counter; i++) {
            System.out.println(i + ": " + Professor.list[i].username + " ");
        }
        System.out.println();
    }
    static void viewStudents() {
        if (Student.counter == 0) {
            System.out.println("There is no student!");
            return;
        }
        for (int i = 0; i < Student.counter; i++) {
            System.out.println(i + ": " + Student.list[i].username + " ");
        }
        System.out.println();
    }
}