public class Lesson {
    static int counter = 0;
    static Lesson[] list = new Lesson[100];

    String name;
    Professor professor;
    int studentCounter = 0;
    int classCapacity;
    Student[] studentList;

    public Lesson(String name, Professor professor, int classCapacity) {
        this.name = name;
        this.professor = professor;
        this.classCapacity = classCapacity;
    }
    boolean addStudent(Student student) {
        if (classCapacity > 0) {
            studentList[studentCounter++] = student;
            classCapacity--;
            return true;
        }
        return false;
    }
    void viewStudentList() {
        if (studentCounter == 0) {
            System.out.println("There are no students!");
            return;
        }
        for (int i = 0; i < studentCounter; i++) {
            System.out.print(i + ": " + studentList[i].username + " ");
        }
        System.out.println();
    }
}
