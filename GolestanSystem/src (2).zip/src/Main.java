import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Food.input();
        Book.input();
        Lesson.input();
        Professor.input();
        Student.input();

        System.out.println("<LOGIN MENU>");
        while (true) {
            System.out.print("Enter your type(1: Admin / 2: Professor / 3: Student / 4: Exit): ");
            Scanner scanner = new Scanner(System.in);
            int inputType = Integer.parseInt(scanner.nextLine());
            if (inputType == 4) {
                Food.output();
                Book.output();
                Lesson.output();
                Professor.output();
                Student.output();
                break;
            }
            System.out.print("Enter username: ");
            String inputUser = scanner.nextLine();
            System.out.print("Enter password: ");
            String inputPass = scanner.nextLine();
            Person p;
            switch(inputType) {
                case 1:
                    p = new Admin(inputUser, inputPass);
                    p.login();
                    break;
                case 2:
                    p = new Professor(inputUser, inputPass);
                    p.login();
                    break;
                case 3:
                    p = new Student(inputUser, inputPass);
                    p.login();
                    break;
            }
        }
    }
}
