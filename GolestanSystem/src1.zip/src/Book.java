public class Book {
    static int counter = 0;
    static Book[] list = new Book[100];

    String name;
    boolean isAvailable = true;
    Student borrower;

    public Book(String name) {
        this.name = name;
    }
    boolean borrow(Student borrower) {
        if (isAvailable) {
            this.borrower = borrower;
            isAvailable = false;
            return true;
        }
        return false;
    }
    void retUrn() {
        borrower = null;
        isAvailable = true;
    }
}
