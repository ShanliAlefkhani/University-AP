public class Professor extends Person{
    static int counter = 0;
    static Professor[] list = new Professor[100];

    int classCounter = 0;
    Lesson[] classList;

    public Professor(String username, String password) {
        super(username, password);
    }
    void setClass(String name) {
        Lesson lesson = new Lesson(name, this);
        classList[classCounter++] = lesson;
        Lesson.list[Lesson.counter++] = lesson;
    }
    void viewClassList() {
        for (int i = 0; i < classCounter; i++) {
            System.out.print(i + ": " + classList[i].name + " ");
        }
        System.out.println();
    }
}
