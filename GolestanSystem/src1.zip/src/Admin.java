public class Admin extends Person{
    public Admin(String username, String password) {
        super(username, password);
    }
    void addBook(String name) {
        Book book = new Book(name);
        Book.list[Book.counter++] = book;
    }
    void addFood(String name, long price, int number) {
        Food food = new Food(name, price, number);
        Food.list[Food.counter++] = food;
    }
    void showProfessorInfo(Professor professor) {
        System.out.println(professor.username + " " + professor.password);
    }
    void showStudentInfo(Student student) {
        System.out.println(student.username + " " + student.password);
    }
    static void viewBooks() {
        for (int i = 0; i < Book.counter; i++) {
            System.out.println(i + ": " + Book.list[i].name + " ");
        }
        System.out.println();
    }
    static void viewFoods() {
        for (int i = 0; i < Food.counter; i++) {
            System.out.println(i + ": " + Food.list[i].name + " ");
        }
        System.out.println();
    }
    static void viewLessons() {
        for (int i = 0; i < Lesson.counter; i++) {
            System.out.println(i + ": " + Lesson.list[i].name + " ");
        }
        System.out.println();
    }
    static void viewProfessors() {
        for (int i = 0; i < Professor.counter; i++) {
            System.out.println(i + ": " + Professor.list[i].username + " ");
        }
        System.out.println();
    }
    static void viewStudents() {
        for (int i = 0; i < Student.counter; i++) {
            System.out.println(i + ": " + Student.list[i].username + " ");
        }
        System.out.println();
    }
}