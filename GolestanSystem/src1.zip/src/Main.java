import java.util.Scanner;

public class Main {
    static void adminMenu(Admin admin) {
        boolean bool = true;
        while (bool) {
            System.out.println("0: Add book  1: Add food  2: Show professor info  3: Show student info  4: View books  5: View foods  6: View professors  7: View students  8: Exit");
            System.out.print("Input: ");
            Scanner scanner = new Scanner(System.in);
            int x = scanner.nextInt();
            String nokhodi = scanner.nextLine();

            switch (x) {
                case 0:
                    System.out.print("Enter name of the book: ");
                    String inputName = scanner.nextLine();
                    admin.addBook(inputName);
                    break;
                case 1:
                    System.out.print("Enter name of the food: ");
                    inputName = scanner.nextLine();
                    System.out.print("Enter price of the food: ");
                    long inputPrice = scanner.nextLong();
                    nokhodi = scanner.nextLine();
                    System.out.print("Enter number of the food: ");
                    int inputNumber = scanner.nextInt();
                    nokhodi = scanner.nextLine();
                    admin.addFood(inputName, inputPrice, inputNumber);
                    break;
                case 2:
                    System.out.print("Enter username of the professor: ");
                    inputName = scanner.nextLine();
                    boolean b = true;
                    for (int i = 0; i < Professor.counter; i++) {
                        if (Professor.list[i].username.equals(inputName)) {
                            admin.showProfessorInfo(Professor.list[i]);
                            b = false;
                            break;
                        }
                    }
                    if (b) {
                        System.out.println("There is no professor with this username!");
                    }
                    break;
                case 3:
                    System.out.print("Enter username of the student: ");
                    inputName = scanner.nextLine();
                    b = true;
                    for (int i = 0; i < Student.counter; i++) {
                        if (Student.list[i].username.equals(inputName)) {
                            admin.showStudentInfo(Student.list[i]);
                            b = false;
                            break;
                        }
                    }
                    if (b) {
                        System.out.println("There is no professor with this username!");
                    }
                    break;
                case 4:
                    admin.viewBooks();
                    break;
                case 5:
                    admin.viewFoods();
                    break;
                case 6:
                    admin.viewProfessors();
                    break;
                case 7:
                    admin.viewStudents();
                    break;
                case 8:
                    bool = false;
                    break;
            }
        }
    }
    static void professorMenu(Professor professor) {
        boolean bool = true;
        while (bool) {
            //view class counter inja
            System.out.println("0: Set class  1: View class list  2: Exit");
            System.out.print("Input: ");
            Scanner scanner = new Scanner(System.in);
            int x = scanner.nextInt();
            String nokhodi = scanner.nextLine();

            switch(x) {
                case 0:
                    System.out.print("Enter name of the class: ");
                    String inputName = scanner.nextLine();
                    professor.setClass(inputName);
                    break;
                case 1:
                    professor.viewClassList();
                    break;
                case 2:
                    bool = false;
                    break;
            }
        }
    }
    static void studentMenu(Student student) {
        boolean bool = true;
        while (bool) {
            //view yeseri chiza inja
            System.out.println("0:ViewBookList 1:BorrowBook 2:ReturnBook 3:ViewFoodList 4:AddFood 5:RemoveFood 6:ViewExistedLessonList" +
                    " 7:AddLesson 8:ViewMyLessonList 9:AddMoney 10:Exit");
            System.out.print("Input: ");
            Scanner scanner = new Scanner(System.in);
            int x = scanner.nextInt();
            String nokhodi = scanner.nextLine();

            switch(x) {
                case 0:
                    Admin.viewBooks();
                    break;
                case 1:
                    System.out.print("Enter name of the book: ");
                    String inputName = scanner.nextLine();
                    boolean b = true;
                    for (int i = 0; i < Book.counter; i++) {
                        if (Book.list[i].name.equals(inputName)) {
                            student.borrowBook(Book.list[i]);
                            b = false;
                            break;
                        }
                    }
                    if (b) {
                        System.out.println("This book doesn't exists!");
                    }
                    break;
                case 2:
                    student.returnBook();
                    break;
                case 3:
                    Admin.viewFoods();
                    break;
                case 4:
                    System.out.print("Enter name of the food: ");
                    inputName = scanner.nextLine();
                    b = true;
                    for (int i = 0; i < Food.counter; i++) {
                        if (Food.list[i].name.equals(inputName)) {
                            student.reserveFood(Food.list[i]);
                            b = false;
                            break;
                        }
                    }
                    if (b) {
                        System.out.println("This food doesn't exists!");
                    }
                    break;
                case 5:
                    student.removeFood();
                    break;
                case 6:
                    Admin.viewLessons();
                    break;
                case 7:
                    System.out.print("Enter name of the lesson: ");
                    inputName = scanner.nextLine();
                    b = true;
                    for (int i = 0; i < Lesson.counter; i++) {
                        if (Lesson.list[i].name.equals(inputName)) {
                            student.addLesson(Lesson.list[i]);
                            b = false;
                            break;
                        }
                    }
                    if (b) {
                        System.out.println("This lesson doesn't exists!");
                    }
                    break;
                case 8:
                    student.viewLessonList();
                    break;
                case 9:
                    System.out.print("Enter amount of money: ");
                    long inputMoney = scanner.nextLong();
                    nokhodi = scanner.nextLine();
                    student.addMoney(inputMoney);
                    break;
                case 10:
                    bool = false;
                    break;
            }
        }
    }

    static void login(int inputType, String inputUser, String inputPass) {
        Admin admin = new Admin("admin", "123456");
        switch(inputType) {
            case 1:
                if (inputUser.equals(admin.username) && inputPass.equals(admin.password)) {
                    System.out.println("<ADMIN MENU>");
                    adminMenu(admin);
                }
                else {
                    System.out.println("Input info was wrong!");
                }
                break;
            case 2:
                boolean b = true;
                for (int i = 0; i < Professor.counter; i++) {
                    if (inputUser.equals(Professor.list[i].username) && inputPass.equals(Professor.list[i].password)) {
                        System.out.println("<PROFESSOR MENU>");
                        professorMenu(Professor.list[i]);
                        b = false;
                        break;
                    }
                }
                if (b) {
                    System.out.println("Input info was wrong!");
                }
                break;
            case 3:
                b = true;
                for (int i = 0; i < Student.counter; i++) {
                    if (inputUser.equals(Student.list[i].username) && inputPass.equals(Student.list[i].password)) {
                        System.out.println("<STUDENT MENU>");
                        studentMenu(Student.list[i]);
                        b = false;
                        break;
                    }
                }
                if (b) {
                    System.out.println("Input info was wrong!");
                }
                break;
        }
    }

    public static void main(String[] args) {
        Student.list[Student.counter++] = new Student("student", "123456"); //inja
        Professor.list[Professor.counter++] = new Professor("professor", "123456"); //inja
        System.out.println("<LOGIN MENU>");
        while (true) {
            System.out.print("Enter your type(1: Admin / 2: Professor / 3: Student / 4: Exit): ");
            Scanner scanner = new Scanner(System.in);
            int inputType = scanner.nextInt();
            if (inputType == 4) {
                break;
            }
            String nokhodi = scanner.nextLine();
            System.out.print("Enter username: ");
            String inputUser = scanner.nextLine();
            System.out.print("Enter password: ");
            String inputPass = scanner.nextLine();
            login(inputType, inputUser, inputPass);
        }
    }
}
