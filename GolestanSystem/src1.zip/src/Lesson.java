public class Lesson {
    static int counter = 0;
    static Lesson[] list = new Lesson[100];

    String name;
    Professor professor;
    int studentCounter = 0;
    //int classCapacity; inja
    Student[] studentList;

    public Lesson(String name, Professor professor) {
        this.name = name;
        this.professor = professor;
    }
    void addStudent(Student student) {
        studentList[studentCounter++] = student;
    }
    void removeStudent(Student student) {
        //inja
    }
    void viewStudentList() { //inja
        for (int i = 0; i < studentCounter; i++) {
            System.out.print(i + ": " + studentList[i].username + " ");
        }
        System.out.println();
    }
}
