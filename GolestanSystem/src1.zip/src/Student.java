public class Student extends Person{
    static int counter = 0;
    static Student[] list = new Student[100];

    Lesson[] lessonList;
    int lessonCounter = 0;
    Book borrowedBook;
    Food reservedFood;
    long money;

    public Student(String username, String password) {
        super(username, password);
    }
    void reserveFood(Food food) {
        if (reservedFood == null) {
            if (food.reserve()) {
                if (money >= food.price) {
                    reservedFood = food;
                    money -= food.price;
                }
                else {
                    System.out.println("Your money isn't enough!");
                }
            }
            else {
                System.out.println("this food is finished!");
            }
        }
        else {
            System.out.println("You have already reserved a food!");
        }
    }
    void removeFood() {
        if (reservedFood != null) {
            reservedFood.remove();
            money += reservedFood.price * 90 / 100;
            reservedFood = null;
        }
        else {
            System.out.println("You didn't reserve any food!");
        }
    }
    void borrowBook(Book book) {
        if (borrowedBook == null) {
            if (!book.borrow(this)) {
                System.out.println("This book is already reserved!");
            }
        }
        else {
            System.out.println("You have already borrowed a book!");
        }
    }
    void returnBook() {
        if (borrowedBook != null) {
            borrowedBook.retUrn();
            borrowedBook = null;
        }
        else {
            System.out.println("You didn't borrow any book!");
        }
    }
    void addLesson(Lesson lesson) {
        lesson.addStudent(this);
        lessonList[lessonCounter++] = lesson;
    }
    // void removeLesson(Lesson lesson) inja
    void addMoney(long money) {
        this.money += money;
    }
    void viewLessonList() {
        for (int i = 0; i < lessonCounter; i++) {
            System.out.println(i + ": " + lessonList[i].name + " ");
        }
        System.out.println();
    }
}
